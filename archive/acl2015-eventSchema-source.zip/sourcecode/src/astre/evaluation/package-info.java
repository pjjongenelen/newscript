/**
 *
 * MUC evaluation as described in <br>
 * 'Generative event schema induction with entity disambiguation'
 * 
 */
package astre.evaluation;