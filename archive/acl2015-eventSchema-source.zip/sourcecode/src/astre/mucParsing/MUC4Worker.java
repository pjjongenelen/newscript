package astre.mucParsing;

import java.util.Properties;

import edu.stanford.nlp.pipeline.StanfordCoreNLP;

public class MUC4Worker extends Thread{
	protected static ThreadLocal<StanfordCoreNLP> pipeline = new ThreadLocal<StanfordCoreNLP>();
	protected static ThreadLocal<StanfordCoreNLP> truecasePipeline = new ThreadLocal<StanfordCoreNLP>();
	
	protected MUC4Worker(Runnable r) {
		super(r);
	}
	
	@Override
	public void run() {
	    Properties truecaseProps = new Properties();
	    truecaseProps.put("annotators", "tokenize,ssplit,pos,lemma,truecase");
	    truecaseProps.put("pos.model", 	    		
	    		"/vol/zola/users/nguyen/java-lib/StanfordNLP/" +
	    		"stanford-corenlp-caseless-2013-11-12-models/edu/stanford/nlp/" +
	    		"models/pos-tagger/english-caseless-left3words-distsim.tagger");	    
	    truecasePipeline.set(new StanfordCoreNLP(truecaseProps));
	    
	    Properties props = new Properties();
	    props.put("annotators", "tokenize,ssplit,pos,lemma,ner,parse,dcoref");
	    props.put("parse.maxlen", "100");
	    pipeline.set(new StanfordCoreNLP(props));		
		super.run();
	}
}