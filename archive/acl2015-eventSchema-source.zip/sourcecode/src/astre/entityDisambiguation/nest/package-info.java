/**
 *
 * Full-template model in <br>
 * 'Event schema induction with a probabilistic entity-driven model'
 * 
 */
package astre.entityDisambiguation.nest;