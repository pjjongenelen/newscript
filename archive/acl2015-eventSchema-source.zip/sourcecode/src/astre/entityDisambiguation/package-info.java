/**
 *
 * Slot model in <br>
 * 'Generative Event Schema Induction with Entity Disambiguation'
 * 
 */
package astre.entityDisambiguation;