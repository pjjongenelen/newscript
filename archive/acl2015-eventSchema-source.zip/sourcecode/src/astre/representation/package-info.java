/**
 *
 * Representing (Stanford) parsed documents <br>
 * and entity triples
 * 
 */
package astre.representation;