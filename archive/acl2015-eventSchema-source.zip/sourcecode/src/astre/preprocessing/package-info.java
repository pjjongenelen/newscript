/**
 *
 * Extracting entity triples from document <br>
 * and indexing for induction
 * 
 * 
 */
package astre.preprocessing;